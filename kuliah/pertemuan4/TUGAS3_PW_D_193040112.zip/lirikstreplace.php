<?php 

	$lirik = "if there was a single day i could live <br>
	a single breath i could take <br>
	i'd trade all the others away <br>
	the blood's on the wall <br>
	so you'd might as well just admit it <br>
	and bleach out the stains <br>
	commit to forgetting it <br>
	you're better off empty and blank <br>
	than left with a single pathetic trace of this <br>
	smother another failure, lay this to rest <br>
	console yourself, you're better alone <br>
	destroy yourself, see who gives a fuck <br>
	absorb yourself, you're better alone <br>
	destroy yourself <br>
	i'll chain you to the truth <br>
	for the truth shall set you free <br>
	i'll turn the screws of vengeance and bury you with honesty <br>
	i'll make all your dreams come to life <br>
	and slay them as quickly as they came <br>
	smother another failure, lay this to rest <br>
	console yourself"; 
	
	echo str_replace((["a","i","u","e",]),"o", $lirik);

	 ?>